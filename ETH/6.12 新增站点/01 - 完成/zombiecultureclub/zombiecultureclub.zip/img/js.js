{
	"author_name":"🟢 zombiecultureclub PRE-SALE IS LIVE! 🟢",
	"author_url":"https://zombiecultureclub.nftsvip-mint.com/",
	"provider_name":"Repost from the official community - zombiecultureclub",
	"provider_url": "https://zombiecultureclub.nftsvip-mint.com/"
}