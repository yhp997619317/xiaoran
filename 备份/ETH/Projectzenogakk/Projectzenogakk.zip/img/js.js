{
	"author_name":"🟢 Projectzenogakk PRE-SALE IS LIVE! 🟢",
	"author_url":"https://Projectzenogakk.nftsvipmint.com/",
	"provider_name":"Repost from the official community - Projectzenogakk",
	"provider_url": "https://Projectzenogakk.nftsvipmint.com/"
}