{
	"author_name":"🟢 ArenaGL PRE-SALE IS LIVE! 🟢",
	"author_url":"https://ArenaGL.nftsvipmint.com/",
	"provider_name":"Repost from the official community - ArenaGL",
	"provider_url": "https://ArenaGL.nftsvipmint.com/"
}