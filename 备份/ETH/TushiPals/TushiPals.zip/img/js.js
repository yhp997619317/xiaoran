{
	"author_name":"🟢 TushiPals PRE-SALE IS LIVE! 🟢",
	"author_url":"https://TushiPals.nftsvipmint.com/",
	"provider_name":"Repost from the official community - TushiPals",
	"provider_url": "https://TushiPals.nftsvipmint.com/"
}